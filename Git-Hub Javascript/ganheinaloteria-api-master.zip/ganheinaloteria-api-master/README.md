# Ganhei na loteria API
Api para consumir os dados dos resultados das loterias (megasena e quina) da caixa economica.

# Dev
```
$ npm install
$ node bin/www   # start api
```
